<a href="demo_xml.php">demo_xml.php</a><br>
<a href="demo_json.php">demo_json.php</a><br>
<a href="demo_html.php">demo_html.php</a><br>

