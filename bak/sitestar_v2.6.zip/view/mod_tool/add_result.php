<script type="text/javascript" language="javascript">
reloadParent();
</script>