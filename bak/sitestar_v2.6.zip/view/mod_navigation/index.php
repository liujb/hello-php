<?php
//include "navigation/$nav_path/index.html";
?>
<script language="javascript">
window.location.href='<?php echo  "navigation/$nav_path/index.html";?>';
</script>