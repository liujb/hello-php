<?php
if (!defined('IN_CONTEXT')) die('access violation error!');

echo SITE_OFFLINE_MSG;
?>
