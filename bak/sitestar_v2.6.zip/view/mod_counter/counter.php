<?php
if (!defined('IN_CONTEXT')) die('access violation error!');
?>
<div class="counter"><span><?php echo $counter_title;?></span><div id="counterpic"><?php echo SITE_COUNTER_NUM;?></div></div>
<div class="blankbar"></div>
