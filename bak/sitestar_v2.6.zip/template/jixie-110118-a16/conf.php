<?php
if (!defined('IN_CONTEXT')) die('access violation error!');
$tpl_name = "jixie-110118-a16";
$template_name = "机械A16";
?>