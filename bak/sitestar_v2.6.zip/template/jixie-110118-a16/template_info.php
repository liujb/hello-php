<?php
class TplInfo {
public static $name = 'jixie-110118-a16';
    public static $description = 'A Simple Company Style Template';
    public static $author = 'Jackie Lau';
    public static $email = 'jackie.l@163.com';
    public static $positions = array(
        'logo', 'nav', 'cart', 'banner', 'left', 'right', 'footer','zmd'
    );
}
?>