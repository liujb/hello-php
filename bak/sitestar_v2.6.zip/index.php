<?php
define('IN_CONTEXT', 1);
include_once('load.php');
?>