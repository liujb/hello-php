<?php
if (!defined('IN_CONTEXT')) die('access violation error!');

_e('Licenced error');
?>