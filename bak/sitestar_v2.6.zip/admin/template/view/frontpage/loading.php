<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
</head>
<body>
<div style='text-align:center;'><span><img src='../../../images/Loding.gif'/></span><span style='position:relative;bottom:5px;left:5px;font-size:13px;'>请等待...</span></div>
</body>
</html>
