<?php
if (!defined('IN_CONTEXT')) die('access violation error!');
include_once($_content_);
?>