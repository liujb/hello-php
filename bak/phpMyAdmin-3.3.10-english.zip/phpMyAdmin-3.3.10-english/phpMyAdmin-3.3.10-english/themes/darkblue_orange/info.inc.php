<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Theme information
 *
 * @version $Id$
 * @package phpMyAdmin-theme
 * @subpackage Darkblue_orange
 */

/**
 *
 */
$theme_name = 'Darkblue/orange';
$theme_full_version = '2.9';
?>
